<?php

print "Esto es un boot<br>";
print "Aqui no existe nada de estilo<br>";
print "Localicacion: <b>core/modules/index/boot/page1/boot-default.php</b><br>";

?>